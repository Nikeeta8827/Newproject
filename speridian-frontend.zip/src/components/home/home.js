import Card from 'react-bootstrap/Card';
import * as API from "../../services/service";
import React, { useState, useEffect } from 'react'
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import './home.css';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';


function ImageBody() {
  const [iserror, setIsError] = useState(false);
  const [errormsg, setErrorMsg] = useState('');
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [image, setImage] = useState([])
  const [file, setFile] = useState(null);
  // const [imageView, setImageView] = useState({ preview: '', data: '' })

  useEffect(() => {
    imageDetails();
  }, [])
 
  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };


  useEffect(() => {
    console.log(image)
  }, [image])


  const [details, setDetails] = useState({
    id: "",
    name:"",
    description: "",
    author: "",
    image: "",
  });

  const handleChange = (evt) => {
    const value = evt.target.value;
    if (value === " ") {
      setIsError(true);
      setErrorMsg('Filed is Required *')
    }
    else {
      setIsError(false);
      setErrorMsg('')
      setDetails(state => ({ ...state, [evt.target.name]: value }));
    }
  }
  const imageDetails = () => {
    console.log(image)
    API.getAllImages().then((res) => {
      setImage(res.data.data)
      console.log(res.data.data)
    })
  }
  const deleteImage = (event) => {
    event.preventDefault();
    let id = event.target.id
    API.deleteImagebyId(id).then((res) => {
      alert(res.data.message)
    })
      .catch(error => {
        console.log(error)
      })
  }

  const updateImage = (event) => {
    event.preventDefault();
    let id = event.target.id
    var {name,author,description,image} = details
    var formData = new FormData();
    API.updateImageDetails(id,name,author,description,image=formData.append('file', image.data)).then((res) => {
      // setDetails(res.data.data)
      alert(res.data.message)
      console.log(name,author,description,image)
 
    })
      .catch(error => {
        console.log(error)
      })
  } 

 
  

  return (
    <div>
      <Row xs={1} md={2} className="g-4">
        {image.map((images, index) => (

          <Col key={index}>
            <Card style={{ width: '400px' }}>
              <Card.Header as="h5">Image name: {images.name}</Card.Header>
              <Card.Img variant="top" src={images.image} />
              <Card.Body>
                <Card.Title>ID:{images.id}</Card.Title>
                <Card.Text>Description : {images.description}</Card.Text>
                <Button variant="secondary" onClick={handleShow}>Update</Button>
                {/* opens into a modal */}
                <Modal show={show} onHide={handleClose}>
                  <Modal.Header closeButton>
                    <Modal.Title>Update Image : {images.id}</Modal.Title>
                  </Modal.Header>
                  <Modal.Body>
                    <Form>
                      <Form.Group className="mb-3" controlId="formBasicEmail">
                        <Form.Label>Image Name</Form.Label>
                        <Form.Control type="text" name="name"  onChange={(evt)=> handleChange(evt)} placeholder="Enter image name"  />
                        <Form.Text className="text-muted">
                          Please don't leave it empty.
                        </Form.Text>
                      </Form.Group>

                      <Form.Group className="mb-3" controlId="formBasicPassword">
                        <Form.Label>Description</Form.Label>
                        <Form.Control type="text" name="description"  onChange={(evt) => handleChange(evt)} placeholder="Enter description" />
                      </Form.Group>
                      <Form.Group className="mb-3" controlId="formBasicPassword">
                        <Form.Label>Author</Form.Label>
                        <Form.Control type="text" name="author" onChange={(evt) => handleChange(evt)} placeholder="Enter author" />
                      </Form.Group>
                      <input type="file" name="image" onChange={handleFileChange} />
                      <Button variant="primary" id={images.id} onClick={updateImage} type="submit">
                        Submit
                      </Button>
                    </Form>
                  </Modal.Body>
                  <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                      Close
                    </Button>
                    <Button variant="primary" onClick={handleClose}>
                      Save Changes
                    </Button>
                  </Modal.Footer>
                </Modal>
                <Button variant="danger" id={images.id} onClick={deleteImage} onChange={(evt) => handleChange(evt)}>Delete</Button>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>

    </div>
  )


}

export default ImageBody;
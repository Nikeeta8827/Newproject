import React from 'react'
import './header.css'
import Card from 'react-bootstrap/Card';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import Button from 'react-bootstrap/Button';
import { useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import * as API from "../../services/service";

function Header() {
  const [show, setShow] = useState(false);
  const [iserror, setIsError] = useState(false);
  const [errormsg, setErrorMsg] = useState('');
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [details, setDetails] = useState({
    id: "",
    name:"",
    description: "",
    author: "",
    image: "",
  });
  const handleChange = (evt) => {
    const value = evt.target.value;
    if (value === " ") {
      setIsError(true);
      setErrorMsg('Filed is Required *')
    }
    else {
      setIsError(false);
      setErrorMsg('')
      setDetails(state => ({ ...state, [evt.target.name]: value }));
    }
  }
  const addImage = (event) => {
    let author,name,description,image;
    var formData = new FormData();
    API.addImageDetails(name,author,description,image=formData.append('file', image.data)).then((res) =>{
     alert(res.data.message)
    })
    .catch(error => {
      console.log(error)
    })
  }
  return (
    <>
    <Navbar bg="dark" data-bs-theme="dark">
      <Container>
        <Navbar.Brand href="#home">Speridian</Navbar.Brand>
        <Nav className="me-auto">
          <Nav.Link href="#home">Home</Nav.Link>
          <Nav.Link href="#features">About</Nav.Link>
          <Nav.Link href="#pricing">Pricing</Nav.Link>      
        </Nav>
       
      </Container>
    </Navbar>
    <Button variant="dark" style={{float:"right"}} onClick={handleShow}>+ Add Image</Button>
    <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Add Image Metadata</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Image Name</Form.Label>
              <Form.Control
              name="name"
                type="text"
                placeholder="example"
                autoFocus
                onChange={(evt)=> handleChange(evt)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Description</Form.Label>
              <Form.Control
              name="description"
                type="text"
                placeholder="example"
                onChange={(evt)=> handleChange(evt)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Author</Form.Label>
              <Form.Control
                name="author"
                type="text"
                placeholder="google"
                onChange={(evt)=> handleChange(evt)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Upload Image File:</Form.Label>
              <input type="file" name="image"  />
                      <Button variant="primary" onClick={addImage} type="submit">
                        Submit
                      </Button>
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default Header;
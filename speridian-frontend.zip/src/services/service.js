import axios from 'axios';
const baseUrl = "http://localhost:8000"


// service to get all images list
export const getAllImages=()=>{
    return(
     axios({
       url:`${baseUrl}/images-list`,
       method: 'GET'
     })
     )
     
   } 

//  service to add images
export const addImageDetails = async (name,description,author,image) =>{
    return(
    await  axios({
        url:`${baseUrl}/image`,
        method:'POST',
        data:
        {
          name:name,
          description:description,
          author:author,
          image:image
        }
      })
    )
}  

// service to delete image by id
export const deleteImagebyId = async (id) =>{
    return(
   await  axios({
        url:`${baseUrl}/delete/${id}`,
        method:'DELETE'
      })
    )
}  

//  service to add images
export const updateImageDetails =async (id,name,description,author,image) =>{
    return(
      await axios({
        url:`${baseUrl}/update/${id}`,
        method:'PUT',
        data:
        {
          name:name,
          description:description,
          author:author,
          image:image
        }
      })
    )
}  

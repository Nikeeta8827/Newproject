import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import { useState } from "react";
import React from 'react';
import Header from './components/header/header'
import ImageBody from  './components/home/home'


function App() {
  return (
    
     <div className="App">
      <Header />
      <br></br>
      <ImageBody />
    </div>

  );
}

export default App;

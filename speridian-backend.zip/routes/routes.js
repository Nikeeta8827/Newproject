const express = require('express')
const router = express.Router()

const imageController = require('../controllers/imageController')
const upload = imageController.upload

router.post('/image',upload.single('file'),imageController.uploadImage)
router.get('/images-list', imageController.getAllImages)
router.delete('/delete/:id', imageController.deleteImagebyId)
router.put('/update/:id', upload.single('file'),imageController.updateImageMetadata)



module.exports = router
const express = require('express')
const app = express()
const routes = require("./routes/routes")
const bodyParser = require('body-parser')
var mysql = require('mysql');
const cors = require('cors')
const path = require('path')

app.use('*', cors())
app.use(express.static('../public'))

// mysql connection

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "password",
    database: "speridian"
});

con.connect(function (err) {
    if (err) throw err;
    console.log("Database Connected!");
});

app.use(function (req, res, next) {
    req.con = con;
    next();
})

// using body parser
app.use(bodyParser.json());


app.listen(8000, function (err, data) {
    if (err) {
        console.log("Couldn't connect to 8000")
    }
    console.log("Server started at 8000")
})



app.use("/", routes)

module.exports = app
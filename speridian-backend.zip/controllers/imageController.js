const multer = require('multer');
const path = require('path')
const express = require('express')
const app = express()
var db = require('../index')
app.use(express.static("./public"))
// multer for file storage
var storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, '../public');
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});

var upload = multer({ storage: storage });


// service to upload image and its meta data
const uploadImage = async (req, res, next) => {
    db = req.con;
    let data = {
        id: Math.floor(Math.random() * 1000070),
        name : req.body.name,
        description: req.body.description,
        author: req.body.author,
        image: req.file.filename
    }
    if (data) {
        let addData = await db.query('Insert into imageInfo set ?', [data], function (err, rows) {
            if (err) {
                console.log(err)
                res.send({
                    message: "Sorry data cannot be added.Please try again."
                })
            }
            else {
                res.send({
                    message: "Successfully added data",
                    data: data
                })
            }
        })
    }
    else {
        res.send({
            message: "Please enter all fields"
        })
    }

}


// service to see list of images that are present in db
const getAllImages = async (req, res, next) => {
    try {
        db = req.con;
        console.log("get all images running")
        let listOfImages = await db.query('Select * from imageInfo', function (err, rows) {
            if (err) {
                res.send({
                    message: "Cannot fetch list of images."
                })
            }
            else {
                res.send({
                    message: "Successfully got list of images",
                    data: rows
                })
            }
        })
    }
    catch (error) {
        res.send({
            message: "Couldn't fetch list of images. Please try again"
        })
    }
}

// service to delete any image by passing id
const deleteImagebyId = async (req, res, next) => {
    try {
        var id = req.params.id;
        console.log("Delete Image running")
        let deleteImage = await db.query('Delete from imageInfo where id = ?', id, function (err, rows) {
            if (err) {
                console.log(err)
            }
            else {
                res.send({
                    message: "Image deleted successfully having id:" + id
                })
            }
        })
    }
    catch (error) {
        res.send({
            message: "Couldn't delete image. Please try again"
        })
    }
}

// update images metadata service
const updateImageMetadata = async(req,res,next) => {
    try{
        console.log("update image running")
        var id = req.params.id
        let data = {
            name : req.body.name,
            description: req.body.description,
            author: req.body.author,
            image: req.file.filename
        }

        let results = await db.query("Update imageInfo set [name=?,description=?,author=?,image=?] where id = ?",[data.image,data.description,data.author,data.image,id], function(err,rows){
            if(err){
                console.log(err)
            }
            console.log("update image success")
            res.send({
                
                message:"Updated successfully image having id:"+id,
                data:rows
            })
        })


    }
    catch(error){
        res.send({
            message: "Couldn't update image. Please try again"
        })
    }
}

module.exports = { uploadImage, upload, getAllImages, deleteImagebyId ,updateImageMetadata}